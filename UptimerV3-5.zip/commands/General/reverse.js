module.exports = {
    name: "reverse",
    description: "Reverses the given text",
    run: async(client, message, args) => {
        const text = args.join(" ")
        if(!text) return message.reply("Please give something to reverse!")
        let Rarray = text.split("")
        let reverseArray = Rarray.reverse()
        let result = reverseArray.join("")
        message.channel.send(result)
    }
}





/**
 * @INFO
 * Bot Coded by Enjoyer#5368 |
 *https://www.youtube.com/channel/UCu4ArGHs_gD2UBuOGJGMwTQ
 * @INFO
 * Please mention Him , when using this Code!
 * @INFO
 */