const api = require("srod-v2");
const Discord = require("discord.js");
const colors = require('./../../colors.json')

module.exports = {
  name: "advice",
  aliases: [],
  description: "Return A Random Advice!",
  usage: "Advice",
  run: async (client, message, args) => {
    
    const Data = await api.GetAdvice({ Color: "#39d822" });
    return message.channel.send(Data);
  }
};


/**
 * @INFO
 * Bot Coded by Enjoyer#5368 |
 *https://www.youtube.com/channel/UCu4ArGHs_gD2UBuOGJGMwTQ
 * @INFO
 * Please mention Him , when using this Code!
 * @INFO
 */